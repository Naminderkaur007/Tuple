

//1:)   Tuples allow you to store several values together in a single value. That might sound like arrays, but tuples are different:

//2:)   You can’t add or remove items from a tuple; they are fixed in size.

//3:)   You can’t change the type of items in a tuple; they always have the same types they were created with.

//4:)   You can access items in a tuple using numerical positions or by naming them, but Swift won’t let you read numbers or names that don’t exist.






import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        useOfTupleForSwitch()
     }
 

    func useOfTupleForSwitch(){
        
        let switchTuple = (First: true, Second: false)
        
        switch switchTuple {
        case (true, true):
            print("true, true")
        case (true, false):
            print("true, false")
        case (false, true):
            print("false, true")
        case (false, false):
            print("false, false")
        }
    }
    

    func useOfTupleForSwaping(){
    //        Tuples are useful to swap values between 2 (or more) variables without using temporary variables.
            var a = "Naminder"
            var b = "Samyra"
            (b,a) = (a,b)
            print("a = \(a)")
            print("b = \(b)")
        }

    func tupleReturner()->(Int, String){
          return (100, "Hundred")
      }

      func useOfTupleAsReturnFunc(){
          let myTuple = self.tupleReturner()
          print("First Value = \(myTuple.0)")
          print("Second Value = \(myTuple.1)")
      }
    
    func useOfTupleMeans(){
            
    //        Tuples group multiple values into a single compound value. The values within a tuple can be of any type and do not have to be of the same type as each other.
            
            let tuple = ("one", 2, "three", true,["1","2","3"],["1":"first","2":"second"],22.3,(Apple:"Hello",Mango:2))
            
            
            print("first value of tuple = \(tuple.0)")
            
            
            print("second value of tuple = \(tuple.1)")
            print("third value of tuple = \(tuple.2)")
            print("fourth value of tuple = \(tuple.3)")
            print("fifth value of tuple = \(tuple.4)")
            print("sixth value of tuple = \(tuple.5)")
            print("seventh value of tuple = \(tuple.7.Apple)")
            
            let arrayGet = tuple.4
            print("Tuple have array object = \(arrayGet)")
            
            
    //        They can also be named when being used as a variable and even have the ability to have optional values inside:
            var numbers: (apple: Int?, middle: String, last: Int)
            numbers = (nil, "dos", 3)
            print("number tuple = \(numbers)")
        }
    
     func useOfGetFromTuple(){
        
            let myTuple = (name : "Naminder kaur", age : 40, course : "computers")
        
        
            let (first, second, third) = myTuple
        
            print("first = \(first)")
            print("second = \(second)")
            print("third = \(third)")
            
            
    //        Specific properties can be ignored by using underscore (_):
            let longTuple = ("abc", 123, "xyz")
        
            let (_,_,thirdd) = longTuple
            print("third = \(thirdd)")
        }
        
    
    
    
}

